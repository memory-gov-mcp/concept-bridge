# 机制抽取协议（承接 Agent 子任务）

你会拿到若干 `batch-NNN.view.txt`。每个文件含多篇论文，格式：

```
=== paper_id=W123 | domain=biology | year=2001
TITLE: ...
[0] 第一句原文
[1] 第二句原文
```

`[k]` 是句子编号。**你不复制原文证据**，只给出支持该机制的句子区间 `sent_range: [i, j]`
（i==j 表示单句；i<j 表示连续多句，必须真正连续且共同支持该机制）。
上游会按该区间从原始摘要中机械切片生成 evidence.span，因此证据必然与原文精确一致。

## 输出

对每个 view 文件，写一个同名 `.json`（如 `batch-007.json`），内容为对象：

```json
{
  "W123": {"status": "ok", "mechanisms": [ {...}, {...} ]},
  "W456": {"status": "no_supported_mechanism", "reason": "具体原因"},
  "W789": {"status": "failed", "reason": "具体原因"}
}
```

文件必须覆盖该 view 中出现的**全部** paper_id，一个都不能漏。

## 机制对象字段（严格）

```json
{
  "sent_range": [2, 3],
  "subject": {"surface": "原文中的主体写法", "type": "structure"},
  "action": {"verb": "inhibit", "action_class": "inhibit", "polarity": "inhibit"},
  "object": {"surface": "原文中的客体写法", "type": "process"},
  "conditions": ["high_temperature"],
  "result": "受证据支持的具体结果，中文表述",
  "causality": "direct",
  "confidence": 0.85
}
```

- `type` 只能取：structure、process、substance、signal、state。
- `action_class` 只能取：inhibit、promote、transport、transform、recognize、amplify、
  stabilize、degrade、compete、isolate、trigger、regulate。
- `polarity` 只能取：promote、inhibit、neutral。
- `causality` 只能取：direct、mediated、feedback、threshold。threshold 只在原文确有阈值/临界条件时用。
- `verb` 保留原文具体动作（可用原文动词，如 "catalyze"、"suppress"、"couple"）。
- `conditions` 用英文 snake_case，只写原文明确支持的条件；没有就 `[]`。
- `confidence` 0–1 之间的主观判断。

## 硬性规则

1. **主体与客体必须是不同实体**（归一后 concept_id 不同）。不要写成 "membrane" vs "membranes"
   这类同一概念，也不要主客体同名。
2. 每篇 `ok` 给 **1–5 条**机制，由独立机制事实的数量决定，不要为凑数拆分同一事实。
   同一事实换个说法 = 重复，会被退回。
3. `surface` 必须是**原文里出现的实体写法**（英文论文就用英文原文写法，德文/其他语种同理），
   不要翻译、不要自己造词。
4. `result` 用中文忠实概括该证据说的结果。**不得添加原文没有的数值、效果、条件或确定性**。
   原文是推测/提议/"may"/"suggest"/"postulated"，result 里要保留这种语气。
5. `sent_range` 必须覆盖该机制的关键动作与结果。宁可多覆盖一两句（连续），
   也不要指向不含该因果关系的句子。
6. 摘要只是**章节目录、书评元数据、网站样板文字、仅有术语罗列、或被截断到没有因果内容**时，
   用 `no_supported_mechanism`，reason 写清楚是哪一类（例如"摘要为章节标题罗列"）。
   不要为这类摘要编造机制。
7. 摘要有实质内容时要尽力抽取，不要偷懒给 no_supported_mechanism。
   综述类摘要若陈述了具体因果机制（如"X 通过 Y 调控 Z"），照样抽。
8. 非英语摘要（德语、法语、中文等）照常处理，surface 用原文写法，result 用中文。

## 质量优先级

证据可定位 > 机制真实 > 数量。编造或改写原文会被上游校验直接退回。
