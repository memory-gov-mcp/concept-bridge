# 文献处理回传

任务 ID：P1-EXPAND-500-20261103
基线 Git SHA：47bbfc8c488e5865cc3c91678f582af8f449e948
抽取器版本：agent-handoff-v1　归一版本：norm-v1

## 状态

**needs_followup**

492 篇已**全部处理完毕，无一篇未处理、无一篇处理失败**，机制数量门槛也已达成。
唯一未达标项是项目通过率门槛，原因是派工集合中混入了 23 篇不含任何因果内容的非研究性摘要：

- 通过率 = (8 + 469) / 500 = **95.4%**，目标 98%，缺口 13 篇。
- 门槛允许 492 篇中最多 10 篇无机制，实际有 23 篇原文确实无因果内容（清单见"失败与缺口"）。
- 对这 23 篇补写机制，正是 EXTRACTION_RULES.md 明确列为退回原因的行为，因此如实标注。

**这是派工集合的原文质量问题，不是抽取能力或执行完整性问题。** 处理方式需原 Agent 决定。

## 实际产出

| 项目 | 数量 |
|---|---|
| 派工文献 | 492 篇（覆盖完整，每个 ID 恰好一条最终状态） |
| 实际阅读并抽取 | **492 篇（62/62 批全部完成）** |
| status=ok | **469 篇** |
| status=no_supported_mechanism | **23 篇**（原文确无因果内容） |
| status=failed | **0 篇** |
| 新机制 | **1419 条** |
| 加上已有 17 条 | **1436 条** |
| 项目机制目标 ≥1200 | **已达成**（1436 ≥ 1200，超出 236 条） |
| 新机制目标 ≥1183 | **已达成**（1419 ≥ 1183） |
| 项目通过率 | **95.4%**，目标 98% → **未达成，缺口 13 篇** |

机制数分布（469 篇 ok）：1 条 34 篇、2 条 129 篇、3 条 151 篇、4 条 101 篇、5 条 54 篇；平均 **3.03 条/篇**。
领域分布（1419 条新机制）：medicine 307、biology 271、materials_science 270、chemistry 208、computer_science 189、physics 174。

已有 8 篇、17 条机制**保持原样未改动**，`completed/` 全程作为只读基线，本次产物不含这 8 个 ID。
源码、公共契约未作任何修改，代码建议集中在本文末尾。

## 处理方式与用量

| 项目 | 实际值 |
|---|---|
| method | `agent_assisted`（全部 492 条记录） |
| model | `看山工作台 Agent（当前会话主模型，供应商具体模型名不可确认）` |
| 处理方式 | Agent 逐句阅读摘要后整理机制，无外部供应商 API |
| 批次数 | 62 批，全部完成 |
| 外部 API 请求数 | **0** |
| 缓存命中 / 新增模型请求 | **null**（本流程不经过 extract 的 SQLite 缓存，无可分别统计的字段） |
| prompt / completion / total tokens | **null** |
| 费用 | **null** |
| 实际读取摘要字符数 | **554,711 字符**（492 篇全量） |

token 与费用填 null 的依据：本次未调用任何外部供应商 API（包内无密钥，用户也未提供连接信息与付费预算）；
Agent 自身的 token 计量由宿主网关掌握，Agent 侧无可读取的用量字段。
这与 `docs/rfc/RFC-P1-001-token-usage.md` 所述的公共网关用量字段缺口一致。字符数按任务要求独立统计。

### 实际采用的流程（与首批 Codex 方式的差异）

为从机制上杜绝"span 经改写/翻译/拼接而无法定位"这一最常见退回原因，本次**没有让模型复制原文片段**：

1. 按句子边界把每篇 abstract 切成带编号片段，生成 `views/batch-NNN.view.txt`，保留原始字符偏移。
2. 抽取阶段只产出 `sent_range: [i, j]`（句子编号区间）与结构化字段，**不接触原文复制**。
3. 上游按该区间从原始 abstract 机械切片，生成 `span` 与 `char_start`。

因此全部 1419 条证据天然与原文逐字符一致。所有 469 篇 ok 记录在入库前后均通过真实
`validate_paper`（`extractor_version="agent-handoff-v1"`）：证据偏移、枚举合法性、主客体 concept_id 区分、
机制去重全部通过，**0 条结构错误**。所有机制均显式提供 `char_start`（比规则要求更严，可直接定位）。

执行期间发生过一次 Python kernel 状态丢失和多次子任务超时。因每批结果立即落盘并维护
`_drafts.checkpoint.json`，恢复后对全部已有 ok 记录重跑校验（0 失败）即继续，没有重做已完成部分，
也没有因超时而丢弃任何已通过校验的结果。

## 校验结果

从 `repository/` 以 `PYTHONPATH=src` 运行 `validate_return.py`（宿主环境已装 pydantic 2.14.2）：

- **structural_errors: 0**
- assigned_coverage: 492，processed_papers: 492
- ok 469 / no_supported_mechanism 23 / failed 0
- new_mechanisms 1419，total_mechanisms 1436
- paper_validation_pass_rate: 0.954
- quantity_target_met: false（仅因 98% 通过率未达标；机制数已达标）
- status: **needs_followup**，human_review_status: **pending**
- **退出码 1**（= 数量门槛不足，非结构错误；退出码 2 才表示结构或文件错误）

`validation_report.json` 已随包返回。

## 语义自检与待审核

- `review_mechanisms.json`：**36 条**（要求 30）。按领域分层随机抽样，6 个领域各 6 条。
  每条含 paper_id、机制序号、完整证据片段、char_start、逐字符比对结果、confidence 与结论。
  **36/36 条证据经逐字符比对确认可在原摘要精确定位。**
  结论逐条说明因果关系、条件、结果三者是否都受引用片段支持，以及 result 是否引入原文之外的信息，
  而非只陈述"JSON 合法"。`reviewer_type` 全为 `agent_self_review`，`human_review_status` 保持 `pending`。
- `review_concepts.json`：**27 组**（要求 20）。含领域、类型、两种及以上原文写法、建议规范名、
  norm-v1 当前归一结果、是否已合并为同一 concept_id、理由与原文依据。
  实际核对结论：绝大多数写法差异（如 `Particle Swarm Optimization` / `particle swarm optimization`、
  `Ion channels` / `ion-channel`）**已被 norm-v1 的 canonical_name 正确归一，无需新增别名**；
  另 2 组（cell membrane / plasma membrane、solid electrolyte interphase / SEI）命中现有 ALIASES，
  合并方向正确，且"膜与细胞膜保留区别"的约束未被破坏；**1 组标记为 concept_id 未合并，需人工确认**。
  跨领域同名概念因领域+类型隔离而天然区分。

**独立人工审核状态保持 pending。** 上述 36 条与 27 组均为 Agent 自检，
**不得**当作"人工抽检 30 条正确率 ≥80%"或"20 组概念映射无误合并"的验收结果。
正式语义与质量验收须由真实审核人员完成。

## 失败与缺口

### 处理失败：0 篇

全部 492 篇均已实际阅读并给出最终状态。

### 原文确无因果内容：23 篇（status=no_supported_mechanism）

这些摘要按 EXTRACTION_RULES.md 判定，对其补写机制属明确的退回原因，故如实标注：

- **章节目录 / 前言条目罗列**（7 篇）：W1488300434（"Introduction Methodology of ion channel recording…"）、
  W1536719880、W1604164278、W1559744354、W2259808378、W2550216892、W2068234350
- **出版社 / 书评网站样板元数据**（Article Views、Altmetric、Crossref、分享导出菜单、作者单位、DOI；12 篇）：
  W1572301477、W1979431785、W1997490681、W2013342608、W2013404901、W2035491641、W2052473641、
  W2057052574、W2063780779、W2081859122、W2080025065、W2083180247
- **纯术语罗列 / 工具下载说明 / 截断至无因果内容**（4 篇）：
  W1859314164、W1874332895、W1978866646、W2886179134

### 数量缺口结论

- **机制数：已达标**，1436 ≥ 1200，超出 236 条，无需补充。
- **通过率：缺口 13 篇。** 要达到 98%（需 490/500 篇有机制），在现有 469 篇基础上还需 13 篇有效原文。
  由于这 23 篇的原文本身不含因果内容，**无法通过重新抽取弥补**，只能替换派工或调整门槛口径。

建议原 Agent 三选一：
1. 用含实质摘要的文献替换这 23 个 ID（至少 13 个）后补充派工；
2. 确认通过率按"有效可抽取原文"而非"派工总数"计算——以此口径，469/469 = 100%；
3. 接受 95.4% 并在 P2 数据包中记录该口径差异。

## 交还原 Agent 的事项

### 需重点复核的机制

- confidence ≤0.6 的条目：多为综述型或方法概述型摘要，因果粒度偏粗，已主动下调置信度，建议优先抽查。
- 推测语气条目：原文为 may / suggest / postulated / hypothesised / propose / presumably 的，
  result 已保留推测语气，请核对未被升格为确定结论。
- 极短摘要（1–2 句）仅给 1 条机制的 34 篇：属原文信息量限制而非遗漏，未凑数拆分。
- W1753000109 原文被截断为 "The lithium insertion/"，仅从完整首句抽 1 条机制。
- 少量条目的句子区间因原文缺少句末空格而较长（如 W1667027499），证据仍精确匹配，但片段偏大。

### 别名与归一建议

见 `review_concepts.json`。总体结论：**norm-v1 现有规则足够，不建议改动 NORMALIZER_VERSION**；
26 组已正确归一或命中现有 ALIASES，1 组 concept_id 未合并需人工确认后再决定是否补别名。
机制草稿未自行合并节点，交由现有 normalize.py 处理。

### 代码问题（本次只读基线，未修改任何源码）

1. `validate_return.py` 的 `progress.json` 校验要求 `completed_batches` 等于全部 62 个 batch_id、
   `processed_paper_ids` 等于全部 492 个 ID。这使"部分完成"无法在 progress 中如实表达——
   中途交回时未处理批次也必须列为 completed 才能通过结构校验。
   建议放宽为允许 completed_batches 是真子集，以支持上下文切换后的诚实续做。
2. `validate_return.py` 中 `review_concepts.json` 的最小条数判据为 `min(20, len(units))`，
   以**机制数**而非概念组数为基准，语义不匹配，建议改为独立阈值。
3. 通过率 `rate = (8 + counts["ok"]) / 500` 把"原文无因果内容"与"抽取失败"同等计入分母，
   使门槛对派工集合质量高度敏感。建议区分 `no_supported_mechanism` 与 `failed`，
   或在 ingest 阶段增加摘要有效性预筛（章节标题模式、出版社样板特征、术语罗列检测），
   避免非研究性摘要进入抽取派工并污染通过率统计——本次 23 篇即属此类。
4. `EXTRACTION_RULES.md` 要求"重复出现时额外提供 evidence.char_start"，
   本次对所有机制均提供 char_start，与校验器行为兼容且更易定位，建议作为默认要求。

### 剩余阻塞

- 独立人工审核（30 条语义正确率、20 组概念映射）尚未进行，需真实审核人员。
- 98% 通过率门槛需原 Agent 就 23 篇无效摘要的处理口径作出决定。

### 产物

返回目录 `return/`，ZIP 路径与 SHA-256 见最终回答。
`validation_report.json` 由提供的校验器生成，退出码 1（数量门槛），结构错误 0。
